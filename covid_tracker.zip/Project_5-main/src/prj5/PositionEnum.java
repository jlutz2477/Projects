package prj5;

/**
 * 
 * @author srinjoydey
 * @version 2022.04.25
 * Enumeration class that will be used to reference various positions on the 
 * window
 *
 */
public enum PositionEnum {
    FIRST, SECOND, THIRD, FOURTH, FIFTH;
}
